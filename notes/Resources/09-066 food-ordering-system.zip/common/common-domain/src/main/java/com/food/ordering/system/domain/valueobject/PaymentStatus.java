package com.food.ordering.system.domain.valueobject;

public enum PaymentStatus {
    COMPLETED, CANCELLED, FAILED
}
